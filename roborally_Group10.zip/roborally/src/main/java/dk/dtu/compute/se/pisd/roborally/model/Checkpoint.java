package dk.dtu.compute.se.pisd.roborally.model;

public class Checkpoint {
    int priority;
    public Checkpoint(int priority){
        this.priority = priority;
    }
}
